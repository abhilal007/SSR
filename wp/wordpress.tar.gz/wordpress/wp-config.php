<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'lal123');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ygF%`5nM0C,B_$wFr~m[% RL+ukuaKlcvLP@vY|9AgxJFuw/0MK(@w/4R/KMIVu1');
define('SECURE_AUTH_KEY',  '(TGVHJA9sn|H?^ y7?BSV^$A@/bHG{[,bVmWH(x~Q9nc2RacI?n1 ,mm~k.Y X?8');
define('LOGGED_IN_KEY',    'AN8m?ujb5TT p_Me.yoD5H< y5?EuM %UL1gU0)AnnH[u;IDA3.GShiuMw&6}UAE');
define('NONCE_KEY',        'LSuTd9-+!QYT|[@i2tFv5RB&Ha`tiJ}_.g^hgBAYw`4xhbBwr_ao;Sx6r?1b9w(K');
define('AUTH_SALT',        '3$^K]8P$X}#W}x7viU|ArCPIj7sjA mCP$SH.oL@]-iq15k=?!Y bWrr2,Px$RlY');
define('SECURE_AUTH_SALT', 'e}I[>Iv5}0l}p$}2Eg~]96-@2:)]rpUdgHUr@hd~e9K*ErIgCy]zTX:GR=}Wi3rO');
define('LOGGED_IN_SALT',   'T|kH<{uXWtly0k9hw]^tiR|n!X:VC,t@JAJcDYTSo+fNSOylcdvaOzyx*)Di)@QJ');
define('NONCE_SALT',       ',R{+Sj)k{q-RWPSsZ{8y5P#)-0PVn{0f94T2cQnAj7<VuoIa-_e,|,uXgAX}.nyG');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define( 'FS_METHOD', 'direct' );
